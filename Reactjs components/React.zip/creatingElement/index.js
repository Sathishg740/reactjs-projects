const element=React.createElement('h1',null,'Welcome to ReactJS')
ReactDOM.render(element,document.getElementById('container'))