import React from 'react'
import moment from 'moment'
const Article = () => {
  return <h2>article component</h2>
}

export default Article
